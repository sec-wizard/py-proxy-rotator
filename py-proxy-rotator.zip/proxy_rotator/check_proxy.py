import random
import requests
import time


class checkProxy:
    def __init__(self, protocol, givenTimeout):
        self.protoc = protocol
        self.file = open(self.protoc + '.txt', 'r')
        self.freshList = self.file.read().splitlines()
        self.timeout = givenTimeout

    def check_proxies(self):
        for i in self.freshList:
            x = 0
            while x == 0:
                try:
                    d = requests.get("http://ip-api.com/json/", proxies={"http": self.protoc + '://' + i}).text
                    time.sleep(self.timeout)
                    x += 1
                    print(d)
                except:
                    continue

checkProxy('socks5', 3).check_proxies()




"""
i = 0
while i < len(listof):
    new = format_proxy('socks5') + listof[i]
    while time.time() < 5:
        print(get_ip(new))
        i+= 1
"""



